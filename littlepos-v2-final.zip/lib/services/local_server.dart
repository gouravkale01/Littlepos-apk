import 'dart:io';
import 'dart:convert';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_router/shelf_router.dart';
import 'package:network_info_plus/network_info_plus.dart';
import '../database/db_helper.dart';

class LocalServer {
  static HttpServer? _server;
  static int port = 8888;

  static Future<String?> getLocalIpAddress() async {
    final info = NetworkInfo();
    return await info.getWifiIP() ?? '127.0.0.1';
  }

  static Future<void> startServer(Function onStateChanged) async {
    if (_server != null) return;

    final router = Router();

    // Serve HTML Dashboard for Laptop Browser
    router.get('/', (Request request) async {
      final products = await DatabaseHelper.instance.fetchProducts();
      
      String rows = products.map((p) => '''
        <tr>
          <td>\${p['id']}</td>
          <td>\${p['name']}</td>
          <td>\${p['category']}</td>
          <td>\${p['size']}</td>
          <td>₹\${p['price']}</td>
          <td>\${p['stock']}</td>
          <td><code>\${p['barcode']}</code></td>
        </tr>
      ''').join('');

      String html = '''
      <!DOCTYPE html>
      <html>
      <head>
        <title>Kaayansh Collective - PC Browser Portal</title>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 20px; }
          .container { max-width: 1000px; margin: auto; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
          h2 { color: #00796b; margin-top: 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
          th { background: #00796b; color: white; }
          tr:nth-child(even) { background: #f9f9f9; }
          .form-box { background: #e0f2f1; padding: 15px; border-radius: 6px; margin-top: 20px; }
          input, button { padding: 10px; margin: 5px 0; width: 100%; box-sizing: border-box; }
          button { background: #00796b; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; }
          button:hover { background: #004d40; }
        </style>
      </head>
      <body>
        <div class="container">
          <h2>Kaayansh Collective POS - PC Browser Companion</h2>
          <p>Connected live to your Mobile Phone Database over Local Wi-Fi.</p>
          
          <div class="form-box">
            <h3>Add New Product from Laptop</h3>
            <form action="/add" method="POST">
              <input type="text" name="name" placeholder="Product Name (e.g. Kalamkari Suit)" required>
              <input type="text" name="category" placeholder="Category">
              <input type="text" name="size" placeholder="Size (M, L, XL)">
              <input type="number" step="0.01" name="price" placeholder="Price (₹)" required>
              <input type="number" name="stock" placeholder="Stock Quantity" required>
              <button type="submit">Save Product to Mobile Database</button>
            </form>
          </div>

          <h3>Current Inventory Catalog</h3>
          <table>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Category</th>
              <th>Size</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Barcode</th>
            </tr>
            $rows
          </table>
        </div>
      </body>
      </html>
      ''';
      return Response.ok(html, headers: {'content-type': 'text/html; charset=utf-8'});
    });

    // Handle form submission from browser
    router.post('/add', (Request request) async {
      final payload = await request.readAsString();
      final params = Uri.splitQueryString(payload);

      final randomNum = (100000 + (DateTime.now().millisecondsSinceEpoch % 900000));
      
      await DatabaseHelper.instance.insertProduct({
        'name': params['name'] ?? '',
        'category': params['category'] ?? '',
        'size': params['size'] ?? '',
        'price': double.tryParse(params['price'] ?? '0') ?? 0.0,
        'stock': int.tryParse(params['stock'] ?? '1') ?? 1,
        'image_path': null,
        'barcode': 'KY-$randomNum',
      });

      return Response.seeOther('/');
    });

    var handler = const Pipeline().addMiddleware(logRequests()).addHandler(router.call);
    _server = await shelf_io.serve(handler, InternetAddress.anyIPv4, port);
    onStateChanged();
  }

  static Future<void> stopServer(Function onStateChanged) async {
    if (_server != null) {
      await _server!.close(force: true);
      _server = null;
      onStateChanged();
    }
  }

  static bool get isRunning => _server != null;
}
