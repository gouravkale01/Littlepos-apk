import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'dart:math';

/// LittlePOS V2 database. Versioned, offline-first and additive: existing V1
/// products/users are retained and upgraded in place.
class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;
  DatabaseHelper._init();
  Future<Database> get database async => _database ??= await _initDB('kaayansh_pos.db');

  Future<Database> _initDB(String filePath) async {
    final dir = await getApplicationDocumentsDirectory();
    return openDatabase(join(dir.path, filePath), version: 4,
      onCreate: _createDB, onUpgrade: _upgradeDB,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'));
  }
  Future<String> getImagesDirectory() async {
    final dir = Directory(join((await getApplicationDocumentsDirectory()).path, 'product_images'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir.path;
  }
  Future<void> _createDB(Database db, int version) async {
    await db.execute('CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL, pin_hash TEXT, active INTEGER NOT NULL DEFAULT 1)');
    await db.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, size TEXT, price REAL NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0, image_path TEXT, barcode TEXT UNIQUE, personal_code TEXT UNIQUE, cost_price REAL NOT NULL DEFAULT 0, archived INTEGER NOT NULL DEFAULT 0, gst_rate REAL NOT NULL DEFAULT 0, hsn TEXT, created_at TEXT)');
    await _createV2Tables(db);
    await db.insert('users', {'username':'admin','password':'password123','role':'Admin','active':1});
  }
  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    // Preserve every existing V1 row; add columns only when absent.
    await _addColumn(db,'users','pin_hash','TEXT');
    await _addColumn(db,'users','active','INTEGER NOT NULL DEFAULT 1');
    await _addColumn(db,'products','personal_code','TEXT');
    await _addColumn(db,'products','cost_price','REAL NOT NULL DEFAULT 0');
    await _addColumn(db,'products','archived','INTEGER NOT NULL DEFAULT 0');
    await _addColumn(db,'products','gst_rate','REAL NOT NULL DEFAULT 0');
    await _addColumn(db,'products','hsn','TEXT');
    await _addColumn(db,'products','created_at','TEXT');
    if (await _tableExists(db,'sales')) {
      await _addColumn(db,'sales','subtotal','REAL NOT NULL DEFAULT 0');
      await _addColumn(db,'sales','discount_amount','REAL NOT NULL DEFAULT 0');
      await _addColumn(db,'sales','tax_amount','REAL NOT NULL DEFAULT 0');
      await _addColumn(db,'sales','customer_id','INTEGER');
      await _addColumn(db,'sales','status',"TEXT NOT NULL DEFAULT 'completed'");
      await _addColumn(db,'sales','gst_enabled','INTEGER NOT NULL DEFAULT 0');
      await _addColumn(db,'sales','notes','TEXT');
    }
    if (await _tableExists(db,'sale_items')) {
      await _addColumn(db,'sale_items','product_id','INTEGER');
      await _addColumn(db,'sale_items','cost_price','REAL NOT NULL DEFAULT 0');
      await _addColumn(db,'sale_items','discount_amount','REAL NOT NULL DEFAULT 0');
      await _addColumn(db,'sale_items','tax_rate','REAL NOT NULL DEFAULT 0');
      await _addColumn(db,'sale_items','tax_amount','REAL NOT NULL DEFAULT 0');
      await _addColumn(db,'sale_items','hsn','TEXT');
    }
    await _createV2Tables(db);
    await _addColumn(db,'company_settings','place_of_supply','TEXT');
    await _addColumn(db,'company_settings','pan','TEXT');
    await _addColumn(db,'company_settings','email','TEXT');
    if(await _tableExists(db,'customers')) await _addColumn(db,'customers','gstin','TEXT');
    await db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_products_personal_code ON products(personal_code) WHERE personal_code IS NOT NULL AND personal_code != ""');
  }
  Future<bool> _tableExists(Database db,String table) async {
    final r=await db.rawQuery('SELECT name FROM sqlite_master WHERE type=\"table\" AND name=?',[table]);
    return r.isNotEmpty;
  }
  Future<void> _addColumn(Database db,String table,String column,String definition) async {
    final cols = await db.rawQuery('PRAGMA table_info($table)');
    if (cols.any((c) => c['name']==column)) return;
    await db.execute('ALTER TABLE $table ADD COLUMN $column $definition');
  }
  Future<void> _createV2Tables(Database db) async {
    final statements = <String>[
      'CREATE TABLE IF NOT EXISTS product_variants(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, size TEXT, color TEXT, stock INTEGER NOT NULL DEFAULT 0, barcode TEXT UNIQUE, FOREIGN KEY(product_id) REFERENCES products(id))',
      'CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT UNIQUE,email TEXT,address TEXT,gstin TEXT,created_at TEXT)',
      'CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,gstin TEXT)',
      'CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_no TEXT UNIQUE,total REAL NOT NULL DEFAULT 0,subtotal REAL NOT NULL DEFAULT 0,discount_amount REAL NOT NULL DEFAULT 0,tax_amount REAL NOT NULL DEFAULT 0,payment_method TEXT,customer_id INTEGER,status TEXT NOT NULL DEFAULT "completed",gst_enabled INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,notes TEXT)',
      'CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER NOT NULL,product_id INTEGER,variant_id INTEGER,product_name TEXT NOT NULL,size TEXT,color TEXT,quantity INTEGER NOT NULL,unit_price REAL NOT NULL,cost_price REAL NOT NULL DEFAULT 0,discount_amount REAL NOT NULL DEFAULT 0,tax_rate REAL NOT NULL DEFAULT 0,tax_amount REAL NOT NULL DEFAULT 0,hsn TEXT,line_total REAL NOT NULL,FOREIGN KEY(sale_id) REFERENCES sales(id))',
      'CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_no TEXT UNIQUE,supplier_id INTEGER,total REAL NOT NULL DEFAULT 0,payment_method TEXT,created_at TEXT NOT NULL,notes TEXT)',
      'CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER NOT NULL,product_id INTEGER NOT NULL,variant_id INTEGER,quantity INTEGER NOT NULL,cost_price REAL NOT NULL,line_total REAL NOT NULL,FOREIGN KEY(purchase_id) REFERENCES purchases(id))',
      'CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,category TEXT,amount REAL NOT NULL,payment_method TEXT,created_at TEXT NOT NULL,notes TEXT)',
      'CREATE TABLE IF NOT EXISTS returns(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER NOT NULL,product_id INTEGER,variant_id INTEGER,quantity INTEGER NOT NULL,refund_amount REAL NOT NULL,reason TEXT,created_at TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT,note_type TEXT NOT NULL,note_no TEXT UNIQUE,reference_sale_id INTEGER,customer_id INTEGER,amount REAL NOT NULL,reason TEXT,created_at TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS company_settings(id INTEGER PRIMARY KEY CHECK(id=1),business_name TEXT,logo_path TEXT,address TEXT,phone TEXT,gstin TEXT,gst_registered INTEGER NOT NULL DEFAULT 0,state_code TEXT,invoice_prefix TEXT DEFAULT "KYC",invoice_counter INTEGER NOT NULL DEFAULT 1,place_of_supply TEXT,pan TEXT,email TEXT)',
      'CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,variant_id INTEGER,quantity_change INTEGER NOT NULL,reason TEXT NOT NULL,reference_id INTEGER,created_at TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,action TEXT NOT NULL,entity TEXT,entity_id INTEGER,details TEXT,created_at TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS daily_closings(id INTEGER PRIMARY KEY AUTOINCREMENT,business_date TEXT UNIQUE,cash_expected REAL NOT NULL DEFAULT 0,cash_actual REAL NOT NULL DEFAULT 0,upi_total REAL NOT NULL DEFAULT 0,card_total REAL NOT NULL DEFAULT 0,other_total REAL NOT NULL DEFAULT 0,difference REAL NOT NULL DEFAULT 0,notes TEXT,created_at TEXT NOT NULL)'
    ];
    for (final sql in statements) { await db.execute(sql); }
    await db.insert('company_settings', {'id':1,'business_name':'Kaayansh Collective','gst_registered':0,'invoice_prefix':'KYC','invoice_counter':1}, conflictAlgorithm: ConflictAlgorithm.ignore);
    await db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_products_personal_code ON products(personal_code) WHERE personal_code IS NOT NULL AND personal_code != ""');
  }

  String _pinDigest(String salt,String value) => sha256.convert(utf8.encode('$salt:$value')).toString();
  Future<Map<String,dynamic>?> authenticateUser(String username,String password) async {
    final rows=await (await database).query('users',where:'username=? AND active=1',whereArgs:[username]);
    if(rows.isEmpty) return null;
    final user=rows.first;
    final hash=user['pin_hash'] as String?;
    var valid=false; if(hash!=null && hash.isNotEmpty && hash.contains(':')){final parts=hash.split(':');valid=parts.length==2 && parts[1]==_pinDigest(parts[0],password);} else {valid=user['password']==password;}
    return valid?user:null;
  }
  Future<int> saveStaffUser({required String username,required String pin,required String role}) async {
    if(username.trim().isEmpty || !RegExp(r'^\d{4,8}$').hasMatch(pin)) throw Exception('Username and a 4 to 8 digit PIN required');
    final db=await database; final random=Random.secure(); final salt=List<int>.generate(16,(_)=>random.nextInt(256)).map((v)=>v.toRadixString(16).padLeft(2,'0')).join();
    return db.insert('users',{'username':username.trim(),'password':'','pin_hash':'$salt:${_pinDigest(salt,pin)}','role':role,'active':1},conflictAlgorithm:ConflictAlgorithm.abort);
  }
  Future<List<Map<String,dynamic>>> fetchUsers() async => (await database).query('users',columns:['id','username','role','active'],orderBy:'username');
  Future<void> setUserActive(int id,bool active) async => (await database).update('users',{'active':active?1:0},where:'id=?',whereArgs:[id]);
  Future<String> databaseFilePath() async { final dir=await getApplicationDocumentsDirectory(); return join(dir.path,'kaayansh_pos.db'); }
  Future<void> closeDatabaseForRestore() async { final db=_database; if(db!=null){await db.close();_database=null;} }

  Future<int> insertProduct(Map<String,dynamic> row) async {
    final db=await database;
    final code=(row['personal_code'] as String?)?.trim();
    final barcode=(row['barcode'] as String?)?.trim();
    if(code!=null && code.isNotEmpty && (await db.query('products',where:'personal_code=?',whereArgs:[code])).isNotEmpty) throw Exception('Personal product code already exists');
    if(barcode!=null && barcode.isNotEmpty && ((await db.query('products',where:'barcode=?',whereArgs:[barcode])).isNotEmpty || (await db.query('product_variants',where:'barcode=?',whereArgs:[barcode])).isNotEmpty)) throw Exception('Barcode already exists');
    row['created_at'] ??= DateTime.now().toIso8601String();
    return db.insert('products',row);
  }
  Future<int> updateProduct(int id,Map<String,dynamic> values) async {
    final db=await database;
    final code=values['personal_code']; final barcode=values['barcode'];
    if(code!=null && (await db.query('products',where:'personal_code=? AND id!=?',whereArgs:[code,id])).isNotEmpty) throw Exception('Personal code already in use');
    if(barcode!=null && (await db.query('products',where:'barcode=? AND id!=?',whereArgs:[barcode,id])).isNotEmpty) throw Exception('Barcode already in use');
    return db.update('products',values,where:'id=?',whereArgs:[id]);
  }
  Future<List<Map<String,dynamic>>> fetchProducts({bool includeZeroStock=true,bool includeArchived=false}) async {
    final db=await database;
    final where=<String>[]; final args=<Object>[];
    if(!includeArchived){where.add('archived=0');}
    if(!includeZeroStock){where.add('stock>0');}
    return db.query('products',where:where.isEmpty?null:where.join(' AND '),whereArgs:args.isEmpty?null:args,orderBy:'id DESC');
  }
  /// Legacy delete API now archives; transaction history is never cascade-deleted.
  Future<int> deleteProduct(int id) async => archiveProduct(id);
  Future<int> archiveProduct(int id) async => (await database).update('products',{'archived':1},where:'id=?',whereArgs:[id]);
  Future<int> addVariant(int productId,String size,String color,int stock,{String? barcode}) async {
    final db=await database;
    if(barcode!=null && ((await db.query('product_variants',where:'barcode=?',whereArgs:[barcode])).isNotEmpty || (await db.query('products',where:'barcode=?',whereArgs:[barcode])).isNotEmpty)) throw Exception('Variant barcode already exists');
    final id=await db.insert('product_variants',{'product_id':productId,'size':size,'color':color,'stock':stock,'barcode':barcode});
    await db.insert('stock_movements',{'product_id':productId,'variant_id':id,'quantity_change':stock,'reason':'opening_stock','created_at':DateTime.now().toIso8601String()});
    return id;
  }
  Future<List<Map<String,dynamic>>> variantsForProduct(int id) async => (await database).query('product_variants',where:'product_id=?',whereArgs:[id]);
  Future<int> addCustomer(String name,{String? phone,String? email,String? address,String? gstin}) async => (await database).insert('customers',{'name':name,'phone':phone,'email':email,'address':address,'gstin':gstin,'created_at':DateTime.now().toIso8601String()});
  Future<int> addSupplier(String name,{String? phone,String? address,String? gstin}) async => (await database).insert('suppliers',{'name':name,'phone':phone,'address':address,'gstin':gstin});
  Future<int> recordPurchase({required int productId, int? variantId, required int quantity, required double costPrice, int? supplierId, String? paymentMethod, String? notes}) async {
    if(quantity<=0 || costPrice<0) throw ArgumentError('Invalid purchase quantity or cost');
    final db=await database; return db.transaction((txn) async {
      final total=quantity*costPrice; final now=DateTime.now().toIso8601String();
      final pid=await txn.insert('purchases',{'purchase_no':'PUR-${DateTime.now().millisecondsSinceEpoch}','supplier_id':supplierId,'total':total,'payment_method':paymentMethod,'created_at':now,'notes':notes});
      await txn.insert('purchase_items',{'purchase_id':pid,'product_id':productId,'variant_id':variantId,'quantity':quantity,'cost_price':costPrice,'line_total':total});
      if(variantId!=null){await txn.rawUpdate('UPDATE product_variants SET stock=stock+? WHERE id=?',[quantity,variantId]);}
      await txn.rawUpdate('UPDATE products SET stock=stock+?,cost_price=? WHERE id=?',[quantity,costPrice,productId]);
      await txn.insert('stock_movements',{'product_id':productId,'variant_id':variantId,'quantity_change':quantity,'reason':'purchase','reference_id':pid,'created_at':now});
      return pid;
    });
  }
  Future<int> recordExpense(String title,double amount,{String? category,String? paymentMethod,String? notes}) async {
    if(amount<=0) throw ArgumentError('Expense must be greater than zero');
    return (await database).insert('expenses',{'title':title,'category':category,'amount':amount,'payment_method':paymentMethod,'created_at':DateTime.now().toIso8601String(),'notes':notes});
  }
  Future<int> createSale({required List<Map<String,dynamic>> items,required String paymentMethod,required double total,double discountAmount=0,double taxAmount=0,int? customerId,bool gstEnabled=false}) async {
    final db=await database; return db.transaction((txn) async {
      final now=DateTime.now().toIso8601String();
      final settingsRows=await txn.query('company_settings',where:'id=1'); final settings=settingsRows.isEmpty?{'invoice_prefix':'INV','invoice_counter':1}:settingsRows.first; final counter=(settings['invoice_counter'] as int? ?? 1); final invoiceNo='${settings['invoice_prefix']??'INV'}-${counter.toString().padLeft(6,'0')}'; await txn.update('company_settings',{'invoice_counter':counter+1},where:'id=1');
      final saleId=await txn.insert('sales',{'invoice_no':invoiceNo,'total':total,'subtotal':items.fold<double>(0,(s,i)=>s+((i['quantity'] as num)*(i['unit_price'] as num))), 'discount_amount':discountAmount,'tax_amount':taxAmount,'payment_method':paymentMethod,'customer_id':customerId,'status':'completed','gst_enabled':gstEnabled?1:0,'created_at':now});
      for(final item in items){final q=item['quantity'] as int; final productId=item['product_id'] as int?; final variantId=item['variant_id'] as int?;
        if(variantId!=null){final r=await txn.query('product_variants',where:'id=?',whereArgs:[variantId]); if(r.isNotEmpty && (r.first['stock'] as int)<q) throw Exception('Insufficient variant stock'); await txn.rawUpdate('UPDATE product_variants SET stock=stock-? WHERE id=?',[q,variantId]);}
        if(productId!=null){final r=await txn.query('products',where:'id=?',whereArgs:[productId]); if(r.isNotEmpty && (r.first['stock'] as int)<q) throw Exception('Insufficient product stock'); await txn.rawUpdate('UPDATE products SET stock=MAX(0,stock-?) WHERE id=?',[q,productId]);}
        await txn.insert('sale_items',{'sale_id':saleId,'product_id':productId,'variant_id':variantId,'product_name':item['product_name']??item['name']??'Product','size':item['size'],'color':item['color'],'quantity':q,'unit_price':item['unit_price'],'cost_price':item['cost_price']??0,'discount_amount':item['discount_amount']??0,'tax_rate':item['tax_rate']??0,'tax_amount':item['tax_amount']??0,'hsn':item['hsn'],'line_total':item['line_total']??q*(item['unit_price'] as num)});
        if(productId!=null) await txn.insert('stock_movements',{'product_id':productId,'variant_id':variantId,'quantity_change':-q,'reason':'sale','reference_id':saleId,'created_at':now});
      }
      return saleId;
    });
  }
  Future<void> cancelSale(int saleId,{String? reason}) async {
    final db=await database; await db.transaction((txn) async {
      final sale=(await txn.query('sales',where:'id=?',whereArgs:[saleId])).first;
      if(sale['status']=='cancelled') return;
      final items=await txn.query('sale_items',where:'sale_id=?',whereArgs:[saleId]);
      for(final item in items){final q=item['quantity'] as int; final pid=item['product_id'] as int?; final vid=item['variant_id'] as int?;
        if(vid!=null) await txn.rawUpdate('UPDATE product_variants SET stock=stock+? WHERE id=?',[q,vid]);
        if(pid!=null){await txn.rawUpdate('UPDATE products SET stock=stock+? WHERE id=?',[q,pid]); await txn.insert('stock_movements',{'product_id':pid,'variant_id':vid,'quantity_change':q,'reason':'sale_cancelled','reference_id':saleId,'created_at':DateTime.now().toIso8601String()});}
      }
      await txn.update('sales',{'status':'cancelled','notes':reason},where:'id=?',whereArgs:[saleId]);
    });
  }
  Future<int> recordReturn({required int saleId,required int productId,int? variantId,required int quantity,required double refundAmount,required String reason}) async {
    final db=await database; return db.transaction((txn) async {
      final now=DateTime.now().toIso8601String(); final id=await txn.insert('returns',{'sale_id':saleId,'product_id':productId,'variant_id':variantId,'quantity':quantity,'refund_amount':refundAmount,'reason':reason,'created_at':now});
      if(variantId!=null) await txn.rawUpdate('UPDATE product_variants SET stock=stock+? WHERE id=?',[quantity,variantId]);
      await txn.rawUpdate('UPDATE products SET stock=stock+? WHERE id=?',[quantity,productId]);
      await txn.insert('stock_movements',{'product_id':productId,'variant_id':variantId,'quantity_change':quantity,'reason':'customer_return','reference_id':id,'created_at':now}); return id;
    });
  }
  Future<int> createNote(String type,double amount,String reason,{int? saleId,int? customerId}) async => (await database).insert('notes',{'note_type':type,'note_no':'${type.toUpperCase()}-${DateTime.now().millisecondsSinceEpoch}','reference_sale_id':saleId,'customer_id':customerId,'amount':amount,'reason':reason,'created_at':DateTime.now().toIso8601String()});
  Future<void> saveCompanySettings(Map<String,dynamic> values) async => (await database).insert('company_settings',{'id':1,...values},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<Map<String,dynamic>> getCompanySettings() async => (await database).query('company_settings',where:'id=1').then((r)=>r.first);
  Future<Map<String,double>> profitSummary({String? from,String? to}) async {
    final db=await database; final where=<String>["s.status='completed'"]; final args=<Object>[];
    if(from!=null){where.add('s.created_at>=?');args.add(from);} if(to!=null){where.add('s.created_at<=?');args.add(to);}
    final r=await db.rawQuery('SELECT COALESCE(SUM(si.line_total-si.tax_amount),0) revenue, COALESCE(SUM(si.cost_price*si.quantity),0) cost FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE ${where.join(' AND ')}',args);
    final expenses=await db.rawQuery('SELECT COALESCE(SUM(amount),0) amount FROM expenses ${from==null&&to==null?'':'WHERE created_at>=? AND created_at<=?'}',from==null&&to==null?[]:[from??'0000',to??'9999']);
    final revenue=(r.first['revenue'] as num).toDouble(); final cost=(r.first['cost'] as num).toDouble(); final exp=(expenses.first['amount'] as num).toDouble();
    return {'revenue':revenue,'cost':cost,'gross_profit':revenue-cost,'expenses':exp,'net_profit':revenue-cost-exp};
  }
  Future<int> saveDailyClosing({required String date,required double cashExpected,required double cashActual,required double upi,required double card,required double other,String? notes}) async => (await database).insert('daily_closings',{'business_date':date,'cash_expected':cashExpected,'cash_actual':cashActual,'upi_total':upi,'card_total':card,'other_total':other,'difference':cashActual-cashExpected,'notes':notes,'created_at':DateTime.now().toIso8601String()},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<List<Map<String,dynamic>>> fetchSales() async => (await database).query('sales',orderBy:'id DESC');
  Future<List<Map<String,dynamic>>> fetchExpenses() async => (await database).query('expenses',orderBy:'id DESC');
  Future<void> audit(String action,{String? entity,int? entityId,String? details,String? username}) async => (await database).insert('audit_log',{'username':username,'action':action,'entity':entity,'entity_id':entityId,'details':details,'created_at':DateTime.now().toIso8601String()});
}
