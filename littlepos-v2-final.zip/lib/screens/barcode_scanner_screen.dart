import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class BarcodeScannerScreen extends StatefulWidget {
  const BarcodeScannerScreen({super.key});
  @override State<BarcodeScannerScreen> createState()=>_BarcodeScannerScreenState();
}
class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  bool _handled=false;
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: const Text('Scan product barcode')),
    body: Stack(children:[MobileScanner(onDetect:(capture){if(_handled)return;final code=capture.barcodes.isEmpty?null:capture.barcodes.first.rawValue;if(code!=null&&code.isNotEmpty){_handled=true;Navigator.pop(context,code);}}),
      const Align(alignment:Alignment.bottomCenter,child:Padding(padding:EdgeInsets.all(24),child:Text('Barcode ko frame ke andar rakhein',style:TextStyle(color:Colors.white,backgroundColor:Colors.black54))))]),
  );
}
