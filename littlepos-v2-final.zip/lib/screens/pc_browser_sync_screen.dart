import 'package:flutter/material.dart';
import '../services/local_server.dart';

class PcBrowserSyncScreen extends StatefulWidget {
  const PcBrowserSyncScreen({super.key});

  @override
  State<PcBrowserSyncScreen> createState() => _PcBrowserSyncScreenState();
}

class _PcBrowserSyncScreenState extends State<PcBrowserSyncScreen> {
  String? _ipAddress;
  bool _isRunning = false;

  @override
  void initState() {
    super.initState();
    _isRunning = LocalServer.isRunning;
    _loadIp();
  }

  Future<void> _loadIp() async {
    final ip = await LocalServer.getLocalIpAddress();
    setState(() {
      _ipAddress = ip;
    });
  }

  void _toggleServer() async {
    if (_isRunning) {
      await LocalServer.stopServer(() {
        setState(() => _isRunning = false);
      });
    } else {
      await LocalServer.startServer(() {
        setState(() => _isRunning = true);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PC Browser Manager'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Try Kaayansh POS with a web browser on your Laptop!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal),
            ),
            const SizedBox(height: 12),
            const Text(
              'If you enter the following address into your laptop browser, you can access your mobile POS database on your PC. Make sure your phone and laptop are connected to the same Wi-Fi or mobile hotspot.',
              style: TextStyle(fontSize: 14, height: 1.5, color: Colors.black87),
            ),
            const SizedBox(height: 30),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.teal.shade200),
              ),
              child: Column(
                children: [
                  const Text(
                    'Browser URL Address:',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  SelectableText(
                    _ipAddress != null ? 'http://$_ipAddress:${LocalServer.port}' : 'Loading IP...',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.teal),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Server Status:',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                Chip(
                  backgroundColor: _isRunning ? Colors.green.shade100 : Colors.red.shade100,
                  label: Text(
                    _isRunning ? 'RUNNING' : 'STOPPED',
                    style: TextStyle(color: _isRunning ? Colors.green.shade800 : Colors.red.shade800, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const Spacer(),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _isRunning ? Colors.red.shade700 : Colors.teal,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: _toggleServer,
              child: Text(
                _isRunning ? 'Stop PC Server' : 'Start PC Server',
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
