import 'dart:io';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import '../database/db_helper.dart';

class BackupRestoreScreen extends StatefulWidget { const BackupRestoreScreen({super.key}); @override State<BackupRestoreScreen> createState()=>_BackupRestoreScreenState(); }
class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
 bool _busy=false;
 Future<void> _backup() async {setState(()=>_busy=true);try{
  final database=await DatabaseHelper.instance.database;await database.rawQuery('PRAGMA wal_checkpoint(FULL)');final dbPath=await DatabaseHelper.instance.databaseFilePath(); final dbFile=File(dbPath); if(!await dbFile.exists()) throw Exception('Database file not found');
  final archive=Archive(); archive.addFile(ArchiveFile('kaayansh_pos.db',await dbFile.length(),await dbFile.readAsBytes()));
  final images=Directory(await DatabaseHelper.instance.getImagesDirectory());
  if(await images.exists()){for(final f in images.listSync(recursive:true).whereType<File>()){archive.addFile(ArchiveFile('product_images/${p.basename(f.path)}',await f.length(),await f.readAsBytes()));}}
  final bytes=ZipEncoder().encode(archive); if(bytes==null) throw Exception('Could not create backup');
  final out=File('${(await Directory.systemTemp.createTemp()).path}/LittlePOS_backup_${DateTime.now().millisecondsSinceEpoch}.zip'); await out.writeAsBytes(bytes);
  await Share.shareXFiles([XFile(out.path)],text:'LittlePOS complete backup');
 }catch(e){_message('$e');}finally{if(mounted)setState(()=>_busy=false);}}
 Future<void> _restore() async {final pick=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['zip'],withData:true);if(pick==null)return;
  final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Restore backup?'),content:const Text('Current database will be replaced. First keep a separate backup of your current data.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Restore'))]));if(ok!=true)return;
  setState(()=>_busy=true);try{final data=pick.files.single.bytes;if(data==null)throw Exception('Could not read selected ZIP');final decoded=ZipDecoder().decodeBytes(data);ArchiveFile? dbEntry;for(final f in decoded.files){if(f.name=='kaayansh_pos.db'){dbEntry=f;break;}}if(dbEntry==null)throw Exception('This ZIP is not a LittlePOS backup');
   await DatabaseHelper.instance.closeDatabaseForRestore();final database=await DatabaseHelper.instance.database;await database.rawQuery('PRAGMA wal_checkpoint(FULL)');final dbPath=await DatabaseHelper.instance.databaseFilePath();await File(dbPath).writeAsBytes(dbEntry.content as List<int>,flush:true);
   final imageDir=Directory(await DatabaseHelper.instance.getImagesDirectory());if(await imageDir.exists())await imageDir.delete(recursive:true);await imageDir.create(recursive:true);
   for(final entry in decoded.files.where((f)=>f.isFile&&f.name.startsWith('product_images/'))){final target=File(p.join(imageDir.path,p.basename(entry.name)));await target.writeAsBytes(entry.content as List<int>,flush:true);}
   _message('Backup restored. Restart LittlePOS to reload all data.');
  }catch(e){_message('Restore failed: $e');}finally{if(mounted)setState(()=>_busy=false);}}
 void _message(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Backup & Restore')),body:Center(child:_busy?const CircularProgressIndicator():Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.backup,size:64),const SizedBox(height:12),const Text('Backup includes your POS database and product images. Keep a copy outside this phone.'),const SizedBox(height:20),SizedBox(width:260,child:FilledButton.icon(onPressed:_backup,icon:const Icon(Icons.cloud_upload),label:const Text('Create & Share Backup'))),const SizedBox(height:8),SizedBox(width:260,child:OutlinedButton.icon(onPressed:_restore,icon:const Icon(Icons.restore),label:const Text('Restore from ZIP')))]))));
}
