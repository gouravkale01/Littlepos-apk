import 'package:flutter/material.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:permission_handler/permission_handler.dart';

class ThermalPrinterScreen extends StatefulWidget {
  final String? receiptText;
  const ThermalPrinterScreen({super.key, this.receiptText});
  @override
  State<ThermalPrinterScreen> createState() => _ThermalPrinterScreenState();
}

class _ThermalPrinterScreenState extends State<ThermalPrinterScreen> {
  List<BluetoothInfo> _devices = [];
  bool _busy = false;
  late final TextEditingController _receipt;
  String _status = 'Pair your 58mm/80mm printer in Android Bluetooth settings first.';

  @override
  void initState() {
    super.initState();
    _receipt = TextEditingController(text: widget.receiptText ?? 'LittlePOS receipt\nThank you!\n');
  }

  Future<void> _print() async {
    try {
      final connected = await PrintBluetoothThermal.connectionStatus;
      if (!connected) throw Exception('Connect a printer first');
      await PrintBluetoothThermal.writeString(
        printText: PrintTextSize(size: 1, text: '${_receipt.text}\n\n\n'),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Print sent to thermal printer')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> _load() async {
    setState(() => _busy = true);
    try {
      final connectPermission = await Permission.bluetoothConnect.request();
      await Permission.bluetoothScan.request();
      final granted = connectPermission.isGranted && await PrintBluetoothThermal.isPermissionBluetoothGranted;
      if (!granted) {
        setState(() => _status = 'Bluetooth permission not granted. Allow it in Android settings.');
        return;
      }
      _devices = await PrintBluetoothThermal.pairedBluetooths;
      setState(() => _status = '${_devices.length} paired device(s) found');
    } catch (e) {
      setState(() => _status = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _connect(BluetoothInfo device) async {
    setState(() => _busy = true);
    try {
      final ok = await PrintBluetoothThermal.connect(macPrinterAddress: device.macAdress);
      setState(() => _status = ok ? 'Connected to ${device.name}' : 'Could not connect to ${device.name}');
      if (ok) {
        await PrintBluetoothThermal.writeString(
          printText: PrintTextSize(size: 2, text: 'LittlePOS printer connected\n'),
        );
        await PrintBluetoothThermal.writeString(
          printText: PrintTextSize(size: 1, text: 'Test print successful\n\n\n'),
        );
      }
    } catch (e) {
      setState(() => _status = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _receipt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Bluetooth Thermal Printer'),
          actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_status),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _busy ? null : _load,
                icon: const Icon(Icons.bluetooth_searching),
                label: const Text('Find paired printers'),
              ),
              if (_busy) const LinearProgressIndicator(),
              Expanded(
                child: ListView(
                  children: [
                    ..._devices.map((device) => ListTile(
                          leading: const Icon(Icons.print),
                          title: Text(device.name),
                          subtitle: Text(device.macAdress),
                          trailing: TextButton(
                            onPressed: () => _connect(device),
                            child: const Text('Connect & Test'),
                          ),
                        )),
                    const Divider(),
                    TextField(
                      controller: _receipt,
                      maxLines: 8,
                      decoration: const InputDecoration(
                        labelText: 'Receipt text',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: _print,
                      icon: const Icon(Icons.print),
                      label: const Text('Print receipt'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}
