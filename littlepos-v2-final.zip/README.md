# LittlePOS V2

Offline-first Flutter POS for a boutique. Android release APK is built with the included GitHub Actions workflow.

## V2 modules in this source

- Inventory with unique personal product code and globally checked product/variant barcode; barcode camera scan when creating products and from the POS billing screen.
- POS billing with size/colour variant selection, bill discount, payment method, customer name, product GST rate/HSN, and stock deduction.
- GST registration settings, GSTIN validation, sequential invoice numbers, PDF tax invoice with HSN and CGST/SGST or IGST split based on configured place of supply. Have a CA verify invoice fields, tax treatment and place-of-supply configuration before statutory use.
- Bluetooth thermal printer discovery for paired devices, connection/test print, and receipt printing from the invoice list (58/80mm ESC/POS text output).
- Database + product-image ZIP backup and restore; restore replaces current local data, so keep an external backup first.
- Staff accounts with Admin/Staff roles and salted SHA-256 PIN hashes. Existing V1 admin `admin / password123` remains available until changed; change this default after first login.
- Purchase, supplier, expense, return, cancellation, daily closing, profit summary, notes, stock movement and audit tables/services from the earlier V2 layer.
- Additive SQLite upgrade from V1 database version 2 to version 4; existing records are retained.

## Build APK using a phone

1. Push this source to the `main` branch of your GitHub repository (or upload/replace the project files there).
2. Open GitHub → Actions → **LittlePOS V2 Android APK** → **Run workflow**.
3. When it finishes, open the workflow run and download the `littlepos-v2-release-apk` artifact.
4. Install the APK. Keep the V1 APK and a separate V1 data backup until V2 has been tested.

## Important validation notes

- This source was assembled without a Flutter/Dart SDK in the authoring environment, so an APK compile, device-camera test, printer hardware test and restore test have not been executed here. GitHub Actions is the required compile check.
- Camera and Bluetooth permissions are inserted by the workflow after Android scaffold generation.
- Pair the thermal printer in Android Bluetooth settings before using the in-app printer screen.
- Backup ZIP should be stored outside the phone. Test restore with a copy before relying on it.
- GST legal invoice requirements depend on business registration, state, transaction type, HSN/SAC and current tax rules. Verify with a Chartered Accountant before issuing invoices.
