# LittlePOS V1 – Offline Boutique POS

Flutter + SQLite boutique inventory and basic billing starter. Android APK is built by the included GitHub Actions workflow. The archive includes Android platform files and a small `ios/` compatibility folder so online IDE importers that check for both platform directories can recognize the project. The iOS folder is only an import placeholder; this V1 is intended for Android phones and PC browsers, not iPhone builds. The cloud workflow regenerates the Android platform with the installed Flutter SDK before compiling, ensuring Gradle wrapper files are created by Flutter.

## What's included in V1

- Offline SQLite product catalogue.
- Product photo, category and selling price.
- Clothing variants: one row per size + colour + stock combination.
- Standard sizes XS, S, M, L, XL, XXL, 3XL and Free Size, plus custom size.
- Standard colour choices plus custom colour.
- Variant-specific barcode and stock count.
- Inventory search, low-stock count and product deletion.
- Basic checkout cart, cash/UPI/card/other payment recording, stock deduction and recent sales.
- Daily sales total.
- Local Wi-Fi browser companion server on port 8888.
- SQLite v1-to-v2 migration: each existing v1 product is preserved and migrated as one `Default` colour variant.

## First login

- Username: `admin`
- Password: `password123`

Change this default password before real shop use. The starter login currently retains the original project's simple local password storage; it is not yet a hardened multi-user authentication system.

## Build an Android APK

### Easiest phone-only option: FlutLab

1. Open [FlutLab](https://flutlab.io/) in your phone browser and create/sign in to an account.
2. Create a Flutter project by uploading this ZIP as the project source.
3. Wait for dependencies to load, then select the Android builder and build the APK.
4. Download the generated APK to the phone and install it. FlutLab documents ZIP project import and Android APK build/device install.

This ZIP includes the `android/` folder and an `ios/` compatibility placeholder. Choose Android for building; the iOS placeholder is not an iPhone build target. If FlutLab still reports an import error, use the GitHub Actions method below, which creates a fresh Android platform with Flutter before compiling.

### Reproducible cloud build using GitHub Actions

The archive includes Android app configuration and manifest files. The GitHub Actions workflow regenerates the Android platform using the installed Flutter SDK (including Gradle wrapper files), fetches packages, runs `flutter analyze`, builds the release APK and stores it as an Actions artifact.

1. Extract this ZIP.
2. Create a private GitHub repository and upload the extracted project files (keep the `.github/workflows/build-apk.yml` file and folder structure).
3. Open the repository's **Actions** tab.
4. Select **Build LittlePOS Android APK** and tap **Run workflow** (or push to `main`).
5. When the workflow is green, open its run, scroll to **Artifacts**, and download `littlepos-v1-release-apk`.
6. Extract the artifact ZIP on the phone. Tap `app-release.apk` to install. If Android asks, allow your browser/file manager to install unknown apps for this install only.

You can do those GitHub steps from a phone browser; no local PC is needed. A GitHub account is required. The first build needs internet because Flutter packages and Android build tools are downloaded in the cloud.

## Build on a computer (optional)

Install Flutter SDK and Android SDK, then run:

```bash
flutter create --platforms=android --org com.kaayansh.littlepos .
python3 tool/patch_android_manifest.py
flutter pub get
flutter analyze
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Mobile-only testing

- Install the release APK on the Android phone.
- Launch LittlePOS and log in.
- Add a product, then add separate variant rows for each size/colour pair (example: M/Black, L/Black, M/Blue). Enter stock separately for each row.
- Open Billing, tap a variant to add it to the cart, change quantities, and checkout using a test payment method. Verify that only the selected variant's stock decreases.
- Close and reopen the app to verify that inventory and sales persist offline.
- For PC-browser testing later, connect the phone and computer to the same Wi-Fi/hotspot and start the browser server in the app.

## Important V1 limitations

This is a first MVP, not yet a production-certified POS. Product editing, refunds/returns, tax/GST invoices, receipt/thermal printer integration, customer/supplier modules, backup/restore UI, robust user roles/password hashing, and authenticated PC browser access are follow-up work. Test sales with dummy data first. The local browser server is intended only for a trusted private LAN; do not expose its port to the public internet.

The source was not compiled in the authoring environment because Flutter/Dart SDKs were unavailable there. The included cloud workflow is the intended build and analyzer verification path; a successful build has not yet been claimed.
