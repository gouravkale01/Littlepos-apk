from pathlib import Path
import xml.etree.ElementTree as ET

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    raise SystemExit('Android manifest not found. Run flutter create --platforms=android first.')
ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
android = '{http://schemas.android.com/apk/res/android}'
tree = ET.parse(manifest)
root = tree.getroot()
needed = {
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.ACCESS_WIFI_STATE',
}
existing = {node.get(android + 'name') for node in root.findall('uses-permission')}
for permission in sorted(needed - existing):
    node = ET.Element('uses-permission')
    node.set(android + 'name', permission)
    root.insert(0, node)
app = root.find('application')
if app is not None:
    app.set(android + 'usesCleartextTraffic', 'true')
tree.write(manifest, encoding='utf-8', xml_declaration=True)
