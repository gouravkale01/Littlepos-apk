# iOS folder compatibility stub

This directory is included so Flutter project importers that expect the standard `ios/` platform directory can recognize the project archive.

LittlePOS V1 is currently being delivered for Android phones and PC browsers. This is not a complete Xcode/iOS build target. Do not select an iOS build for this package. Generate the full iOS platform with `flutter create --platforms=ios .` only if iPhone support is added later.
