package com.kaayansh.littlepos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
