import 'dart:io';
import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;
  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('kaayansh_pos.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final appDir = await getApplicationDocumentsDirectory();
    final dbPath = join(appDir.path, filePath);
    return openDatabase(
      dbPath,
      version: 2,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: _createDB,
      onUpgrade: _upgradeDB,
    );
  }

  Future<String> getImagesDirectory() async {
    final appDir = await getApplicationDocumentsDirectory();
    final imgDir = Directory(join(appDir.path, 'product_images'));
    if (!await imgDir.exists()) await imgDir.create(recursive: true);
    return imgDir.path;
  }

  String _barcode() => 'KY-${DateTime.now().microsecondsSinceEpoch}-${Random().nextInt(900) + 100}';

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL
    )''');
    await db.execute('''CREATE TABLE products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT,
      size TEXT,
      price REAL NOT NULL,
      stock INTEGER NOT NULL DEFAULT 0,
      image_path TEXT,
      barcode TEXT UNIQUE NOT NULL,
      created_at TEXT
    )''');
    await _createV2Tables(db);
    await db.insert('users', {'username': 'admin', 'password': 'password123', 'role': 'Admin'});
  }

  Future<void> _createV2Tables(DatabaseExecutor db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS product_variants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      size TEXT NOT NULL DEFAULT 'Free Size',
      color TEXT NOT NULL DEFAULT 'Default',
      stock INTEGER NOT NULL DEFAULT 0,
      barcode TEXT UNIQUE NOT NULL,
      FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,
      UNIQUE(product_id, size, color)
    )''');
    await db.execute('''CREATE TABLE IF NOT EXISTS sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_no TEXT UNIQUE NOT NULL,
      total REAL NOT NULL,
      payment_method TEXT NOT NULL,
      created_at TEXT NOT NULL
    )''');
    await db.execute('''CREATE TABLE IF NOT EXISTS sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      variant_id INTEGER,
      product_name TEXT NOT NULL,
      size TEXT NOT NULL,
      color TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      line_total REAL NOT NULL,
      FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE,
      FOREIGN KEY(variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
    )''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at)');
  }

  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      // Keep all v1 product rows. Each old product becomes one default-colour variant.
      await db.execute('ALTER TABLE products ADD COLUMN created_at TEXT');
      await _createV2Tables(db);
      final oldProducts = await db.query('products');
      for (final product in oldProducts) {
        final productId = product['id'] as int;
        final oldSize = (product['size'] ?? '').toString().trim();
        final oldBarcode = (product['barcode'] ?? _barcode()).toString();
        await db.insert('product_variants', {
          'product_id': productId,
          'size': oldSize.isEmpty ? 'Free Size' : oldSize,
          'color': 'Default',
          'stock': product['stock'] ?? 0,
          'barcode': oldBarcode,
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
      }
      await db.execute("UPDATE products SET created_at = COALESCE(created_at, datetime('now'))");
    }
  }

  Future<Map<String, dynamic>?> authenticateUser(String username, String password) async {
    final db = await database;
    final rows = await db.query('users', where: 'username = ? AND password = ?', whereArgs: [username, password], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<int> insertProductWithVariants(Map<String, dynamic> product, List<Map<String, dynamic>> variants) async {
    final db = await database;
    return db.transaction((txn) async {
      final productId = await txn.insert('products', {
        'name': product['name'],
        'category': product['category'] ?? '',
        'size': variants.map((v) => v['size']).toSet().join(', '),
        'price': product['price'],
        'stock': variants.fold<int>(0, (sum, v) => sum + (v['stock'] as int)),
        'image_path': product['image_path'],
        'barcode': _barcode(),
        'created_at': DateTime.now().toIso8601String(),
      });
      for (final variant in variants) {
        await txn.insert('product_variants', {
          'product_id': productId,
          'size': variant['size'],
          'color': variant['color'],
          'stock': variant['stock'],
          'barcode': _barcode(),
        });
      }
      return productId;
    });
  }

  // Compatibility for the original PC browser form and older callers.
  Future<int> insertProduct(Map<String, dynamic> row) async {
    final size = (row['size'] ?? 'Free Size').toString().trim();
    return insertProductWithVariants(row, [
      {'size': size.isEmpty ? 'Free Size' : size, 'color': (row['color'] ?? 'Default').toString(), 'stock': row['stock'] ?? 0}
    ]);
  }

  Future<List<Map<String, dynamic>>> fetchProducts() async {
    final db = await database;
    return db.query('products', orderBy: 'id DESC');
  }

  Future<List<Map<String, dynamic>>> fetchInventoryRows({String search = ''}) async {
    final db = await database;
    final term = '%${search.trim()}%';
    return db.rawQuery('''
      SELECT p.id AS product_id, p.name, p.category, p.price, p.image_path,
             v.id AS variant_id, v.size AS size, v.color AS color,
             v.stock AS stock, v.barcode AS barcode
      FROM products p JOIN product_variants v ON v.product_id = p.id
      WHERE p.name LIKE ? OR p.category LIKE ? OR v.size LIKE ? OR v.color LIKE ? OR v.barcode LIKE ?
      ORDER BY p.id DESC, v.size, v.color
    ''', [term, term, term, term, term]);
  }

  Future<int> deleteProduct(int id) async {
    final db = await database;
    return db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> createSale({required List<Map<String, dynamic>> items, required String paymentMethod}) async {
    if (items.isEmpty) throw Exception('Cart is empty');
    final db = await database;
    await db.transaction((txn) async {
      double total = 0;
      for (final item in items) {
        final quantity = item['quantity'] as int;
        final variant = await txn.query('product_variants', where: 'id = ?', whereArgs: [item['variant_id']], limit: 1);
        if (variant.isEmpty) throw Exception('Product variant no longer exists');
        final available = variant.first['stock'] as int;
        if (quantity < 1 || quantity > available) throw Exception('Insufficient stock for ${item['name']}');
        total += (item['price'] as num).toDouble() * quantity;
      }
      final invoice = 'LP-${DateTime.now().millisecondsSinceEpoch}';
      final saleId = await txn.insert('sales', {
        'invoice_no': invoice,
        'total': total,
        'payment_method': paymentMethod,
        'created_at': DateTime.now().toIso8601String(),
      });
      for (final item in items) {
        final quantity = item['quantity'] as int;
        final unitPrice = (item['price'] as num).toDouble();
        await txn.insert('sale_items', {
          'sale_id': saleId,
          'variant_id': item['variant_id'],
          'product_name': item['name'],
          'size': item['size'],
          'color': item['color'],
          'quantity': quantity,
          'unit_price': unitPrice,
          'line_total': unitPrice * quantity,
        });
        await txn.rawUpdate('UPDATE product_variants SET stock = stock - ? WHERE id = ?', [quantity, item['variant_id']]);
        await txn.rawUpdate('''UPDATE products SET stock = (
          SELECT COALESCE(SUM(stock), 0) FROM product_variants WHERE product_id = ?
        ) WHERE id = ?''', [item['product_id'], item['product_id']]);
      }
    });
  }

  Future<List<Map<String, dynamic>>> fetchSales({int limit = 100}) async {
    final db = await database;
    return db.query('sales', orderBy: 'id DESC', limit: limit);
  }

  Future<Map<String, dynamic>> getDashboardStats() async {
    final db = await database;
    final products = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products')) ?? 0;
    final units = Sqflite.firstIntValue(await db.rawQuery('SELECT COALESCE(SUM(stock), 0) FROM product_variants')) ?? 0;
    final low = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM product_variants WHERE stock <= 2')) ?? 0;
    final sales = await db.rawQuery("SELECT COALESCE(SUM(total), 0) AS total FROM sales WHERE date(created_at) = date('now','localtime')");
    return {'products': products, 'units': units, 'low_stock': low, 'today_sales': (sales.first['total'] as num).toDouble()};
  }
}
