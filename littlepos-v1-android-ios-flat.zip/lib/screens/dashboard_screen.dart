import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart' as pw_pdf;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:excel/excel.dart' as ex;
import 'package:open_file/open_file.dart';
import '../database/db_helper.dart';
import 'pc_browser_sync_screen.dart';
import 'login_screen.dart';

const _sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', 'Free Size', 'Custom'];
const _colors = ['Black', 'White', 'Red', 'Blue', 'Green', 'Yellow', 'Pink', 'Beige', 'Brown', 'Navy', 'Multicolor', 'Default', 'Custom'];

class DashboardScreen extends StatefulWidget {
  final String username;
  const DashboardScreen({super.key, required this.username});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _tab = 0;
  List<Map<String, dynamic>> _inventory = [];
  List<Map<String, dynamic>> _sales = [];
  Map<String, dynamic> _stats = {};
  bool _loading = true;
  String _search = '';
  final List<Map<String, dynamic>> _cart = [];

  @override
  void initState() { super.initState(); _refresh(); }

  Future<void> _refresh() async {
    final results = await Future.wait([
      DatabaseHelper.instance.fetchInventoryRows(search: _search),
      DatabaseHelper.instance.fetchSales(),
      DatabaseHelper.instance.getDashboardStats(),
    ]);
    if (!mounted) return;
    setState(() {
      _inventory = results[0] as List<Map<String, dynamic>>;
      _sales = results[1] as List<Map<String, dynamic>>;
      _stats = results[2] as Map<String, dynamic>;
      _loading = false;
    });
  }

  Future<void> _addProduct() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => const _ProductDialog(),
    );
    if (result == null) return;
    try {
      await DatabaseHelper.instance.insertProductWithVariants(result['product'], result['variants']);
      await _refresh();
      if (mounted) _message('Product and variants saved');
    } catch (e) { if (mounted) _message('Could not save product: $e'); }
  }

  Future<void> _deleteProduct(int id, String name) async {
    final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Delete product?'), content: Text('Delete "$name" and all its variants?'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete'))],
    ));
    if (confirm == true) {
      await DatabaseHelper.instance.deleteProduct(id);
      await _refresh();
    }
  }

  void _message(String value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));

  Future<void> _addToCart(Map<String, dynamic> variant) async {
    if ((variant['stock'] as int) < 1) { _message('This variant is out of stock'); return; }
    final index = _cart.indexWhere((e) => e['variant_id'] == variant['variant_id']);
    setState(() {
      if (index >= 0) {
        if (_cart[index]['quantity'] < variant['stock']) _cart[index]['quantity']++;
      } else {
        _cart.add({...variant, 'quantity': 1});
      }
    });
  }

  Future<void> _checkout() async {
    if (_cart.isEmpty) return;
    String payment = 'Cash';
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: const Text('Complete sale'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('Total: ₹${_cart.fold<double>(0, (s, e) => s + (e['price'] as num).toDouble() * (e['quantity'] as int)).toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12), DropdownButtonFormField<String>(value: payment, decoration: const InputDecoration(labelText: 'Payment method'),
          items: const ['Cash', 'UPI', 'Card', 'Other'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setD(() => payment = v ?? 'Cash')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save Sale'))],
    )));
    if (confirmed != true) return;
    try {
      await DatabaseHelper.instance.createSale(items: List<Map<String, dynamic>>.from(_cart), paymentMethod: payment);
      setState(() => _cart.clear());
      await _refresh();
      if (mounted) _message('Sale saved. Stock updated.');
    } catch (e) { if (mounted) _message('Sale not saved: $e'); await _refresh(); }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _inventoryPage(),
      _billingPage(),
      _reportsPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text('LittlePOS · ${widget.username}'),
        backgroundColor: const Color(0xFF155E59), foregroundColor: Colors.white,
        actions: [
          IconButton(tooltip: 'PC browser access', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PcBrowserSyncScreen())), icon: const Icon(Icons.computer)),
          IconButton(tooltip: 'Refresh', onPressed: _refresh, icon: const Icon(Icons.refresh)),
          IconButton(tooltip: 'Logout', onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen())), icon: const Icon(Icons.logout)),
        ],
      ),
      body: _loading ? const Center(child: CircularProgressIndicator()) : pages[_tab],
      bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (v) => setState(() => _tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Stock'),
        NavigationDestination(icon: Icon(Icons.point_of_sale_outlined), selectedIcon: Icon(Icons.point_of_sale), label: 'Billing'),
        NavigationDestination(icon: Icon(Icons.analytics_outlined), selectedIcon: Icon(Icons.analytics), label: 'Reports'),
      ]),
    );
  }

  Widget _stat(String title, String value, IconData icon) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFF0F766E)), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(title, style: const TextStyle(fontSize: 11, color: Colors.black54))]))));

  Widget _inventoryPage() {
    final groups = <int, List<Map<String, dynamic>>>{};
    for (final row in _inventory) { groups.putIfAbsent(row['product_id'] as int, () => []).add(row); }
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 4), child: Row(children: [
        _stat('Products', '${_stats['products'] ?? 0}', Icons.category), const SizedBox(width: 6),
        _stat('Units', '${_stats['units'] ?? 0}', Icons.inventory), const SizedBox(width: 6),
        _stat('Low stock', '${_stats['low_stock'] ?? 0}', Icons.warning_amber),
      ])),
      Padding(padding: const EdgeInsets.fromLTRB(12, 4, 12, 8), child: Row(children: [Expanded(child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search product, size, colour or barcode', border: OutlineInputBorder(), isDense: true), onChanged: (v) async { _search = v; await _refresh(); })), const SizedBox(width: 8), FilledButton.icon(onPressed: _addProduct, icon: const Icon(Icons.add), label: const Text('Add'))])),
      Expanded(child: groups.isEmpty ? const Center(child: Text('No products yet. Tap Add to create your first product.')) : ListView(children: groups.entries.map((entry) {
        final rows = entry.value; final first = rows.first;
        return Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            if (first['image_path'] != null && File(first['image_path']).existsSync()) ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(first['image_path']), width: 54, height: 54, fit: BoxFit.cover)) else Container(width: 54, height: 54, decoration: BoxDecoration(color: Colors.teal.shade50, borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.checkroom, color: Colors.teal)),
            const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(first['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text('${first['category'] ?? 'Uncategorised'} · ₹${(first['price'] as num).toStringAsFixed(2)}') ])),
            IconButton(onPressed: () => _deleteProduct(entry.key, first['name']), icon: const Icon(Icons.delete_outline, color: Colors.red), tooltip: 'Delete product'),
          ]),
          const Divider(),
          ...rows.map((v) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [Expanded(child: Text('${v['size']} · ${v['color']}  |  ${v['stock']} pcs', style: const TextStyle(fontSize: 13))), Text(v['barcode'], style: const TextStyle(fontSize: 10, color: Colors.black54))]))),
        ])));
      }).toList()))
    ]);
  }

  Widget _billingPage() {
    final available = _inventory.where((v) => (v['stock'] as int) > 0).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: Text('New bill', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))), Text('${_cart.length} cart lines') ])),
      Expanded(child: ListView(children: [
        if (available.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('No stock available. Add products in Stock tab.')),
        ...available.map((v) => Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), child: ListTile(
          title: Text(v['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text('${v['size']} · ${v['color']} · Stock ${v['stock']} · ${v['barcode']}'),
          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [Text('₹${(v['price'] as num).toStringAsFixed(2)}'), Icon(Icons.add_circle, color: Colors.teal)]),
          onTap: () => _addToCart(v),
        ))),
        if (_cart.isNotEmpty) ...[
          const Padding(padding: EdgeInsets.fromLTRB(16, 12, 16, 4), child: Text('Cart', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          ..._cart.map((item) => ListTile(title: Text(item['name']), subtitle: Text('${item['size']} · ${item['color']}'), leading: IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => setState(() { item['quantity']--; if (item['quantity'] <= 0) _cart.remove(item); })), trailing: Text('${item['quantity']} × ₹${(item['price'] as num).toStringAsFixed(2)}'))),
        ],
      ])),
      if (_cart.isNotEmpty) SafeArea(child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.teal.shade50, border: Border(top: BorderSide(color: Colors.teal.shade100))), child: Row(children: [Expanded(child: Text('Total  ₹${_cart.fold<double>(0, (s, e) => s + (e['price'] as num).toDouble() * (e['quantity'] as int)).toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), FilledButton.icon(onPressed: _checkout, icon: const Icon(Icons.receipt_long), label: const Text('Checkout'))]))),
    ]);
  }

  Future<void> _exportInventoryPdf() async {
    final pdf = pw.Document();
    final rows = await DatabaseHelper.instance.fetchInventoryRows();
    pdf.addPage(pw.MultiPage(pageFormat: pw_pdf.PdfPageFormat.a4, build: (_) => [
      pw.Header(level: 0, child: pw.Text('LittlePOS Inventory Report')),
      pw.Text('Generated: ${DateTime.now()}'),
      pw.SizedBox(height: 12),
      pw.Table.fromTextArray(headers: ['Product', 'Size', 'Colour', 'Price', 'Stock', 'Barcode'], data: rows.map((v) => [v['name'], v['size'], v['color'], '₹${v['price']}', '${v['stock']}', v['barcode']]).toList()),
    ]));
    await Printing.layoutPdf(onLayout: (_) async => pdf.save());
  }

  Future<void> _exportInventoryExcel() async {
    final rows = await DatabaseHelper.instance.fetchInventoryRows();
    final excel = ex.Excel.createExcel();
    final defaultSheet = excel.getDefaultSheet() ?? 'Sheet1';
    excel.rename(defaultSheet, 'Inventory');
    final sheet = excel['Inventory'];
    sheet.appendRow(['Product', 'Category', 'Size', 'Colour', 'Price', 'Stock', 'Barcode'].map((v) => ex.TextCellValue(v)).toList());
    for (final v in rows) {
      sheet.appendRow([ex.TextCellValue(v['name']), ex.TextCellValue(v['category'] ?? ''), ex.TextCellValue(v['size']), ex.TextCellValue(v['color']), ex.DoubleCellValue((v['price'] as num).toDouble()), ex.IntCellValue(v['stock']), ex.TextCellValue(v['barcode'])]);
    }
    final bytes = excel.encode();
    if (bytes == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'littlepos_inventory_${DateTime.now().millisecondsSinceEpoch}.xlsx'));
    await file.writeAsBytes(bytes, flush: true);
    await OpenFile.open(file.path);
    if (mounted) _message('Excel saved: ${file.path}');
  }

  Widget _reportsPage() => RefreshIndicator(onRefresh: _refresh, child: ListView(padding: const EdgeInsets.all(12), children: [
    Card(child: ListTile(leading: const Icon(Icons.currency_rupee, color: Colors.teal), title: const Text('Today sales'), subtitle: Text('₹${(_stats['today_sales'] ?? 0).toStringAsFixed(2)}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)))),
    Wrap(spacing: 8, runSpacing: 8, children: [OutlinedButton.icon(onPressed: _exportInventoryPdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('Export PDF')), OutlinedButton.icon(onPressed: _exportInventoryExcel, icon: const Icon(Icons.table_chart), label: const Text('Export Excel'))]),
    const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Recent sales', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
    if (_sales.isEmpty) const Text('No sales recorded yet.'),
    ..._sales.map((s) => Card(child: ListTile(leading: const Icon(Icons.receipt), title: Text(s['invoice_no']), subtitle: Text('${s['payment_method']} · ${s['created_at']}'), trailing: Text('₹${(s['total'] as num).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold))))),
  ]));
}

class _VariantDraft {
  String size = 'M';
  String color = 'Black';
  final stock = TextEditingController(text: '1');
  final customSize = TextEditingController();
  final customColor = TextEditingController();
  void dispose() { stock.dispose(); customSize.dispose(); customColor.dispose(); }
  String get actualSize => size == 'Custom' ? customSize.text.trim() : size;
  String get actualColor => color == 'Custom' ? customColor.text.trim() : color;
}

class _ProductDialog extends StatefulWidget {
  const _ProductDialog();
  @override
  State<_ProductDialog> createState() => _ProductDialogState();
}

class _ProductDialogState extends State<_ProductDialog> {
  final _name = TextEditingController();
  final _category = TextEditingController();
  final _price = TextEditingController();
  final List<_VariantDraft> _variants = [_VariantDraft()];
  String? _imagePath;
  bool _saving = false;

  @override
  void dispose() { _name.dispose(); _category.dispose(); _price.dispose(); for (final v in _variants) { v.dispose(); } super.dispose(); }

  Future<void> _pickImage() async {
    final file = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file == null) return;
    final dir = await DatabaseHelper.instance.getImagesDirectory();
    final name = '${DateTime.now().microsecondsSinceEpoch}_${p.basename(file.path)}';
    final saved = await File(file.path).copy(p.join(dir, name));
    if (mounted) setState(() => _imagePath = saved.path);
  }

  void _save() {
    final price = double.tryParse(_price.text.trim());
    if (_name.text.trim().isEmpty || price == null || price < 0) { _snack('Enter product name and a valid price'); return; }
    final variants = <Map<String, dynamic>>[];
    final seen = <String>{};
    for (final v in _variants) {
      final size = v.actualSize;
      final color = v.actualColor;
      final stock = int.tryParse(v.stock.text.trim());
      if (size.isEmpty || color.isEmpty || stock == null || stock < 0) { _snack('Complete every size, colour and stock field'); return; }
      final key = '${size.toLowerCase()}|${color.toLowerCase()}';
      if (!seen.add(key)) { _snack('Duplicate size and colour combination'); return; }
      variants.add({'size': size, 'color': color, 'stock': stock});
    }
    setState(() => _saving = true);
    Navigator.pop(context, {'product': {'name': _name.text.trim(), 'category': _category.text.trim(), 'price': price, 'image_path': _imagePath}, 'variants': variants});
  }

  void _snack(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Add clothing product'),
    content: SizedBox(width: 460, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: _name, decoration: const InputDecoration(labelText: 'Product name *', border: OutlineInputBorder())),
      const SizedBox(height: 10), TextField(controller: _category, decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder())),
      const SizedBox(height: 10), TextField(controller: _price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Selling price (₹) *', border: OutlineInputBorder())),
      const SizedBox(height: 10), Row(children: [if (_imagePath != null) Image.file(File(_imagePath!), width: 48, height: 48, fit: BoxFit.cover) else const Icon(Icons.image, size: 40), const SizedBox(width: 8), TextButton.icon(onPressed: _pickImage, icon: const Icon(Icons.upload), label: const Text('Product photo'))]),
      const Divider(height: 24), const Align(alignment: Alignment.centerLeft, child: Text('Size & colour variants', style: TextStyle(fontWeight: FontWeight.bold))),
      ..._variants.asMap().entries.map((entry) { final i = entry.key; final v = entry.value; return Card(color: Colors.teal.shade50, child: Padding(padding: const EdgeInsets.all(8), child: Column(children: [
        Row(children: [Text('Variant ${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), if (_variants.length > 1) IconButton(onPressed: () => setState(() { _variants.removeAt(i).dispose(); }), icon: const Icon(Icons.close, color: Colors.red))]),
        DropdownButtonFormField<String>(value: v.size, decoration: const InputDecoration(labelText: 'Clothing size'), items: _sizes.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (s) => setState(() => v.size = s ?? 'M')),
        if (v.size == 'Custom') TextField(controller: v.customSize, decoration: const InputDecoration(labelText: 'Enter custom size')),
        const SizedBox(height: 6), DropdownButtonFormField<String>(value: v.color, decoration: const InputDecoration(labelText: 'Colour'), items: _colors.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (c) => setState(() => v.color = c ?? 'Black')),
        if (v.color == 'Custom') TextField(controller: v.customColor, decoration: const InputDecoration(labelText: 'Enter custom colour')),
        TextField(controller: v.stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stock quantity for this size/colour')),
      ]))); }),
      Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: () => setState(() => _variants.add(_VariantDraft())), icon: const Icon(Icons.add), label: const Text('Add another size/colour'))),
      const Text('Tip: Add one row for each combination, e.g. M / Black and L / Black.', style: TextStyle(fontSize: 12, color: Colors.black54)),
    ]))),
    actions: [TextButton(onPressed: _saving ? null : () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: _saving ? null : _save, child: const Text('Save product'))],
  );
}
