import 'package:flutter/material.dart';
import '../database/db_helper.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController(text: 'admin');
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _hidePassword = true;

  Future<void> _login() async {
    setState(() => _isLoading = true);
    final user = await DatabaseHelper.instance.authenticateUser(_usernameController.text.trim(), _passwordController.text);
    if (!mounted) return;
    setState(() => _isLoading = false);
    if (user != null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardScreen(username: user['username'])));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Incorrect username or password')));
    }
  }

  @override
  void dispose() { _usernameController.dispose(); _passwordController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFFEAF4F2),
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420),
      child: Card(elevation: 3, child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Icon(Icons.storefront, size: 54, color: Color(0xFF155E59)),
        const SizedBox(height: 12),
        const Text('LittlePOS', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF155E59))),
        const Text('Offline Boutique POS', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 28),
        TextField(controller: _usernameController, decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.person), border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextField(controller: _passwordController, obscureText: _hidePassword, onSubmitted: (_) => _login(), decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock), border: const OutlineInputBorder(), suffixIcon: IconButton(icon: Icon(_hidePassword ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hidePassword = !_hidePassword)))),
        const SizedBox(height: 20),
        FilledButton(style: FilledButton.styleFrom(backgroundColor: const Color(0xFF155E59), padding: const EdgeInsets.symmetric(vertical: 15)), onPressed: _isLoading ? null : _login, child: _isLoading ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Login')),
        const SizedBox(height: 12),
        const Text('First login: admin / password123', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
        const Text('Change the default password before using it in a shop.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.redAccent)),
      ]))),
    )))),
  );
}
