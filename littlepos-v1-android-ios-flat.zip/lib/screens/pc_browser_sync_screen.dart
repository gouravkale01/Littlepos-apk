import 'package:flutter/material.dart';
import '../services/local_server.dart';

class PcBrowserSyncScreen extends StatefulWidget {
  const PcBrowserSyncScreen({super.key});
  @override
  State<PcBrowserSyncScreen> createState() => _PcBrowserSyncScreenState();
}

class _PcBrowserSyncScreenState extends State<PcBrowserSyncScreen> {
  String? _ipAddress;
  bool _isRunning = false;
  bool _busy = false;

  @override
  void initState() { super.initState(); _isRunning = LocalServer.isRunning; _loadIp(); }

  Future<void> _loadIp() async {
    final ip = await LocalServer.getLocalIpAddress();
    if (mounted) setState(() => _ipAddress = ip);
  }

  Future<void> _toggleServer() async {
    setState(() => _busy = true);
    try {
      if (_isRunning) {
        await LocalServer.stopServer(() { if (mounted) setState(() => _isRunning = false); });
      } else {
        await LocalServer.startServer(() { if (mounted) setState(() => _isRunning = true); });
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Server error: $e')));
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('PC Browser Access'), backgroundColor: const Color(0xFF155E59), foregroundColor: Colors.white),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('Access your phone inventory from a browser', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF155E59))),
      const SizedBox(height: 10),
      const Text('Connect the phone and PC to the same Wi-Fi or phone hotspot. Start the server, then open the address below on the PC.', style: TextStyle(height: 1.5)),
      const SizedBox(height: 20),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [const Text('Browser address'), const SizedBox(height: 8), SelectableText(_ipAddress == null ? 'Loading IP…' : 'http://$_ipAddress:${LocalServer.port}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Color(0xFF155E59)))]))),
      const SizedBox(height: 12),
      ListTile(title: const Text('Server status'), trailing: Chip(label: Text(_isRunning ? 'RUNNING' : 'STOPPED'), backgroundColor: _isRunning ? Colors.green.shade100 : Colors.grey.shade200)),
      const Spacer(),
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(10)), child: const Text('Security note: this V1 browser page has no login protection. Start it only on a trusted private Wi-Fi/hotspot, and stop it when finished. Never expose it to public internet.', style: TextStyle(fontSize: 12))),
      const SizedBox(height: 12),
      FilledButton(onPressed: _busy ? null : _toggleServer, style: FilledButton.styleFrom(backgroundColor: _isRunning ? Colors.red.shade700 : const Color(0xFF155E59), padding: const EdgeInsets.symmetric(vertical: 15)), child: Text(_busy ? 'Please wait…' : _isRunning ? 'Stop browser server' : 'Start browser server')),
    ])),
  );
}
