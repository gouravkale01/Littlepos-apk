import 'dart:io';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_router/shelf_router.dart';
import 'package:network_info_plus/network_info_plus.dart';
import '../database/db_helper.dart';

class LocalServer {
  static HttpServer? _server;
  static int port = 8888;
  static Future<String?> getLocalIpAddress() async {
    return await NetworkInfo().getWifiIP() ?? '127.0.0.1';
  }

  static String _escape(Object? value) => (value ?? '').toString().replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');

  static Future<void> startServer(Function onStateChanged) async {
    if (_server != null) return;
    final router = Router();
    router.get('/', (Request request) async {
      final rows = await DatabaseHelper.instance.fetchInventoryRows();
      final tableRows = rows.map((v) => '<tr><td>${_escape(v['name'])}</td><td>${_escape(v['category'])}</td><td>${_escape(v['size'])}</td><td>${_escape(v['color'])}</td><td>₹${_escape(v['price'])}</td><td>${_escape(v['stock'])}</td><td><code>${_escape(v['barcode'])}</code></td></tr>').join();
      final html = '''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LittlePOS</title><style>body{font-family:Arial;background:#f3f7f6;margin:0;padding:16px;color:#183b38}.wrap{max-width:1100px;margin:auto;background:white;padding:20px;border-radius:14px}h2{color:#155e59}input,button{padding:11px;margin:5px 0;box-sizing:border-box;width:100%}button{background:#155e59;color:white;border:0;border-radius:7px;font-weight:bold}table{width:100%;border-collapse:collapse;margin-top:18px}th,td{padding:9px;border:1px solid #ddd;text-align:left;font-size:13px}th{background:#155e59;color:white}.scroll{overflow:auto}.note{color:#666;font-size:13px}</style></head><body><main class="wrap"><h2>LittlePOS · PC Browser</h2><p class="note">Phone aur PC ko same Wi-Fi ya phone hotspot par connect rakhein. Data phone ke local database mein save hota hai.</p><h3>Quick add product</h3><form action="/add" method="POST"><input name="name" placeholder="Product name" required><input name="category" placeholder="Category"><input name="size" placeholder="Size (M, L, XL)" value="Free Size"><input name="color" placeholder="Colour" value="Default"><input name="price" type="number" step="0.01" min="0" placeholder="Price" required><input name="stock" type="number" min="0" placeholder="Stock" required><button type="submit">Save to phone</button></form><h3>Inventory (${rows.length} variants)</h3><div class="scroll"><table><tr><th>Product</th><th>Category</th><th>Size</th><th>Colour</th><th>Price</th><th>Stock</th><th>Barcode</th></tr>$tableRows</table></div></main></body></html>''';
      return Response.ok(html, headers: {'content-type': 'text/html; charset=utf-8'});
    });
    router.post('/add', (Request request) async {
      final params = Uri.splitQueryString(await request.readAsString());
      final name = (params['name'] ?? '').trim();
      final price = double.tryParse(params['price'] ?? '');
      final stock = int.tryParse(params['stock'] ?? '');
      if (name.isEmpty || price == null || price < 0 || stock == null || stock < 0) return Response(400, body: 'Invalid product details');
      await DatabaseHelper.instance.insertProduct({
        'name': name, 'category': params['category'] ?? '', 'size': params['size'] ?? 'Free Size',
        'color': params['color'] ?? 'Default', 'price': price, 'stock': stock, 'image_path': null,
      });
      return Response.seeOther('/');
    });
    final handler = const Pipeline().addMiddleware(logRequests()).addHandler(router.call);
    _server = await shelf_io.serve(handler, InternetAddress.anyIPv4, port);
    onStateChanged();
  }

  static Future<void> stopServer(Function onStateChanged) async {
    if (_server != null) { await _server!.close(force: true); _server = null; onStateChanged(); }
  }
  static bool get isRunning => _server != null;
}
