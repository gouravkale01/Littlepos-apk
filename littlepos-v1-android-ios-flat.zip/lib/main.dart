import 'package:flutter/material.dart';
import 'database/db_helper.dart';
import 'screens/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseHelper.instance.database;
  runApp(const KaayanshPOSApp());
}

class KaayanshPOSApp extends StatelessWidget {
  const KaayanshPOSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LittlePOS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF155E59)),
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}
