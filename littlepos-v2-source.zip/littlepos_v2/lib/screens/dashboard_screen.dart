import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'dart:math';
import 'package:pdf/pdf.dart' as pw_pdf;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:excel/excel.dart' as ex;
import 'package:open_file/open_file.dart';
import '../database/db_helper.dart';
import 'login_screen.dart';
import 'pc_browser_sync_screen.dart';
import 'v2_business_screen.dart';

class DashboardScreen extends StatefulWidget {
  final String username;
  const DashboardScreen({super.key, required this.username});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Map<String, dynamic>> _products = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    final data = await DatabaseHelper.instance.fetchProducts(includeZeroStock: false);
    setState(() {
      _products = data;
      _isLoading = false;
    });
  }

  String _generateBarcode() {
    final randomNum = Random().nextInt(900000) + 100000;
    return 'KY-$randomNum';
  }

  Future<void> _exportToPDF() async {
    final pdf = pw.Document();

    List<pw.TableRow> rows = [
      pw.TableRow(
        decoration: const pw.BoxDecoration(color: pw_pdf.PdfColors.teal700),
        children: [
          pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('Image', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.white))),
          pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('Name', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.white))),
          pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('Category', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.white))),
          pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('Size', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.white))),
          pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('Price (₹)', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.white))),
          pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('Stock', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.white))),
          pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('Barcode', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.white))),
        ],
      ),
    ];

    for (var product in _products) {
      pw.Widget imgWidget = pw.Container(width: 30, height: 30, color: pw_pdf.PdfColors.grey300);
      final imgPath = product['image_path'] as String?;
      if (imgPath != null && File(imgPath).existsSync()) {
        final imageBytes = File(imgPath).readAsBytesSync();
        imgWidget = pw.Image(pw.MemoryImage(imageBytes), width: 35, height: 35, fit: pw.BoxFit.cover);
      }

      rows.add(
        pw.TableRow(
          children: [
            pw.Padding(padding: const EdgeInsets.all(6), child: imgWidget),
            pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text(product['name'] ?? '')),
            pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text(product['category'] ?? '')),
            pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text(product['size'] ?? '')),
            pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('${product['price']}')),
            pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text('${product['stock']}')),
            pw.Padding(padding: const EdgeInsets.all(6), child: pw.Text(product['barcode'] ?? '')),
          ],
        ),
      );
    }

    pdf.addPage(
      pw.MultiPage(
        pageFormat: pw_pdf.PdfPageFormat.a4,
        build: (context) => [
          pw.Header(
            level: 0,
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Kaayansh Collective - Stock Inventory Report', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: pw_pdf.PdfColors.teal800)),
                pw.Text('Date: ${DateTime.now().toString().substring(0, 10)}', style: const pw.TextStyle(fontSize: 12)),
              ],
            ),
          ),
          pw.SizedBox(height: 10),
          pw.Table(
            border: pw.TableBorder.all(color: pw_pdf.PdfColors.grey400, width: 0.5),
            columnWidths: {
              0: const pw.FlexColumnWidth(0.8),
              1: const pw.FlexColumnWidth(2),
              2: const pw.FlexColumnWidth(1.5),
              3: const pw.FlexColumnWidth(1),
              4: const pw.FlexColumnWidth(1),
              5: const pw.FlexColumnWidth(1),
              6: const pw.FlexColumnWidth(1.5),
            },
            children: rows,
          ),
        ],
      ),
    );

    final imagesDir = Directory(await DatabaseHelper.instance.getImagesDirectory());
    final parentDir = imagesDir.parent;
    final file = File('${parentDir.path}/kaayansh_inventory_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await pdf.save());

    await OpenFile.open(file.path);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('PDF Exported Successfully: ${file.path}')),
    );
  }

  Future<void> _exportToExcel() async {
    var excel = ex.Excel.createExcel();
    String sheetName = excel.getDefaultSheet() ?? 'Sheet1';
    excel.rename(sheetName, 'Inventory');
    ex.Sheet sheetObject = excel['Inventory'];

    sheetObject.appendRow([
      ex.TextCellValue('ID'),
      ex.TextCellValue('Product Name'),
      ex.TextCellValue('Category'),
      ex.TextCellValue('Size'),
      ex.TextCellValue('Price (₹)'),
      ex.TextCellValue('Stock'),
      ex.TextCellValue('Barcode'),
      ex.TextCellValue('Image Path'),
    ]);

    for (var product in _products) {
      sheetObject.appendRow([
        ex.IntCellValue(product['id'] ?? 0),
        ex.TextCellValue(product['name'] ?? ''),
        ex.TextCellValue(product['category'] ?? ''),
        ex.TextCellValue(product['size'] ?? ''),
        ex.DoubleCellValue(product['price'] ?? 0.0),
        ex.IntCellValue(product['stock'] ?? 0),
        ex.TextCellValue(product['barcode'] ?? ''),
        ex.TextCellValue(product['image_path'] ?? ''),
      ]);
    }

    final imagesDir = Directory(await DatabaseHelper.instance.getImagesDirectory());
    final parentDir = imagesDir.parent;
    final file = File('${parentDir.path}/kaayansh_inventory_${DateTime.now().millisecondsSinceEpoch}.xlsx');
    final fileBytes = excel.encode();
    if (fileBytes != null) {
      await file.writeAsBytes(fileBytes);
      await OpenFile.open(file.path);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Excel Exported Successfully: ${file.path}')),
      );
    }
  }

  void _showAddProductDialog() {
    final nameController = TextEditingController();
    final categoryController = TextEditingController();
    final sizeController = TextEditingController();
    final priceController = TextEditingController();
    final stockController = TextEditingController();
    final codeController = TextEditingController();
    final costController = TextEditingController(text: '0');
    String? imagePath;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Add New Boutique Product'),
              content: SingleChildScrollView(
                child: SizedBox(
                  width: 400,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(labelText: 'Product Name (e.g. Kalamkari Suit)'),
                      ),
                      TextField(
                        controller: categoryController,
                        decoration: const InputDecoration(labelText: 'Category (e.g. Kurti Sets)'),
                      ),
                      TextField(
                        controller: sizeController,
                        decoration: const InputDecoration(labelText: 'Sizes Available (e.g. M, L, XL)'),
                      ),
                      TextField(
                        controller: priceController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Price (₹)'),
                      ),
                      TextField(
                        controller: codeController,
                        decoration: const InputDecoration(labelText: 'Personal Product Code (unique)'),
                      ),
                      TextField(
                        controller: costController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Purchase Cost per item (₹)'),
                      ),
                      TextField(
                        controller: stockController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Stock Quantity'),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          imagePath != null
                              ? Image.file(File(imagePath!), width: 60, height: 60, fit: BoxFit.cover)
                              : Container(
                                  width: 60,
                                  height: 60,
                                  color: Colors.grey.shade200,
                                  child: const Icon(Icons.image, color: Colors.grey),
                                ),
                          const SizedBox(width: 16),
                          ElevatedButton.icon(
                            onPressed: () async {
                              final picker = ImagePicker();
                              final pickedFile = await picker.pickImage(source: ImageSource.gallery);
                              if (pickedFile != null) {
                                final imagesDirPath = await DatabaseHelper.instance.getImagesDirectory();
                                final fileName = p.basename(pickedFile.path);
                                final savedImage = await File(pickedFile.path).copy('$imagesDirPath/$fileName');
                                setDialogState(() {
                                  imagePath = savedImage.path;
                                });
                              }
                            },
                            icon: const Icon(Icons.upload),
                            label: const Text('Upload Image'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    if (nameController.text.isEmpty || priceController.text.isEmpty) return;
                    
                    final newProduct = {
                      'name': nameController.text.trim(),
                      'category': categoryController.text.trim(),
                      'size': sizeController.text.trim(),
                      'price': double.tryParse(priceController.text) ?? 0.0,
                      'stock': int.tryParse(stockController.text) ?? 1,
                      'image_path': imagePath,
                      'barcode': _generateBarcode(),
                      'personal_code': codeController.text.trim().isEmpty ? null : codeController.text.trim(),
                      'cost_price': double.tryParse(costController.text) ?? 0.0,
                    };

                    try {
                      await DatabaseHelper.instance.insertProduct(newProduct);
                      if (context.mounted) Navigator.pop(context);
                      _loadProducts();
                    } catch (e) {
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
                    }
                  },
                  child: const Text('Save Product'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kaayansh POS - ${widget.username}'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.computer),
            tooltip: 'PC Browser Manager',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const PcBrowserSyncScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.account_balance),
            tooltip: 'V2 Business Tools',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const V2BusinessScreen())).then((_) => _loadProducts()),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh Inventory',
            onPressed: _loadProducts,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Inventory Catalog & Auto-Barcodes',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Row(
                        children: [
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red.shade700,
                              foregroundColor: Colors.white,
                            ),
                            onPressed: _exportToPDF,
                            icon: const Icon(Icons.picture_as_pdf),
                            label: const Text('Export PDF'),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green.shade700,
                              foregroundColor: Colors.white,
                            ),
                            onPressed: _exportToExcel,
                            icon: const Icon(Icons.table_chart),
                            label: const Text('Export Excel'),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                              foregroundColor: Colors.white,
                            ),
                            onPressed: _showAddProductDialog,
                            icon: const Icon(Icons.add),
                            label: const Text('Add Product'),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: _products.isEmpty
                        ? const Center(child: Text('No products added yet. Click "Add Product" to begin.'))
                        : ListView.builder(
                            itemCount: _products.length,
                            itemBuilder: (context, index) {
                              final product = _products[index];
                              final imgPath = product['image_path'] as String?;
                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 8),
                                child: ListTile(
                                  leading: imgPath != null && File(imgPath).existsSync()
                                      ? Image.file(File(imgPath), width: 50, height: 50, fit: BoxFit.cover)
                                      : Container(
                                          width: 50,
                                          height: 50,
                                          color: Colors.grey.shade200,
                                          child: const Icon(Icons.image_not_supported, color: Colors.grey),
                                        ),
                                  title: Text(product['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                                  subtitle: Text(
                                    'Category: ${product['category']} | Size: ${product['size']} | Stock: ${product['stock']}\nBarcode: ${product['barcode']}',
                                  ),
                                  isThreeLine: true,
                                  trailing: Text(
                                    '₹${product['price']}',
                                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal),
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
